local module = require("arizona-events.core")

local IO          = module.INTERFACE.BitStream.IO
local INCOMING    = module.INTERFACE.INCOMING
local OUTGOING    = module.INTERFACE.OUTGOING
local INCOMING_EX = module.INTERFACE.INCOMING_EX
local OUTGOING_EX = module.INTERFACE.OUTGOING_EX

INCOMING[10] = {
	"onArizonaLoadJs", 
	{ IO.byteArray[16], "_unknown" }, 
	{ IO.maybeEncoded,  "js" }, 
	{ IO.maybeEncoded,  "any" },
	{ IO.uint32,        "server_id" }
}

INCOMING[12] = {
	"onArizonaPlayMediaOnBillboard",
	{ IO.int32,         "billboard_id" },
	{ IO.byteArray[12], "_unknown1" },
	{ IO.maybeEncoded,  "link" },
	{ IO.maybeEncoded,  "user_agent" },
	{ IO.byteArray[12], "_unknown2" }
}

INCOMING[17] = {
	"onArizonaDisplay",
	{ IO.uint32,       "server_id" },
	{ IO.maybeEncoded, "text"}
}

INCOMING[25] = {
	"onArizonaToggleCursor",
	{ IO.uint32, "_unknown1" },
	{ IO.bool8,  "status" },
	{ IO.uint16, "_unknown2" }
}

INCOMING[27] = {
	"onArizonaSetPlayerUnknownState", 
	{ IO.uint16, "player_id" },
	{ IO.bool,   "_unknown1" },
	{ IO.uint8,  "state" }
}

INCOMING[36] = {
	"onArizonaSetChatGroup",
	{ IO.uint8,   "chat_id" },
	{ IO.string8, "command" },
	{ IO.int32,   "color" },
	{ IO.string8, "chat_name" }
}

INCOMING[108] = {
	"onArizonaSwitchChatState",
	{ IO.uint32, "player_id" },
	{ IO.bool,   "is_open" }
}

INCOMING[120] = {
	"onArizonaSetPlayerNametagFlags",
	{ IO.uint16,  "player_id" },
	{ IO.bool,    "_unknown1" },
	{
		{
			{ IO.string8, 1 },
			{ IO.string8, 2 },
			{ IO.string8, 3 },
			{ IO.string8, 4 }
		}, "flags"
	}
}

INCOMING[127] = {
	"onArizonaSetMapIcon",
	{ IO.uint8,         "icon_id" },
	{ IO.byteArray[14], "_unknown1" },
	{ IO.uint16,        "icon_model" },
	{ IO.vector3d,      "position" },
	{ IO.string8,       "icon_name" },
	{ IO.uint8,         "_unknown2" }
}

INCOMING[153] = {
	"onArizonaSetVehicleNumberPlate",
	{ IO.uint16, "vehicle_id" },
	{
		{
			{ IO.uint8,        "type" },
			{ IO.string8,      "text" },
			{ IO.stringUnread, "region" }
		},
		"plate"
	}
}

INCOMING[155] = {
	"onArizonaSetPlayerAttachedObject",
	{ IO.uint16, "player_id" },
	{ IO.int32,  "index" },
	{ IO.bool,   "create" },
	{
		{
			{ IO.int32,    "bone" },
			{ IO.int32,    "model_id" },
			{ IO.vector3d, "offset" },
			{ IO.vector3d, "rotation" },
			{ IO.vector3d, "scale" },
			{ IO.int32,    "color1" },
			{ IO.int32,    "color2" }
		}, "object"
	}
}

INCOMING[165] = {
	"onArizonaLoadBinary",
	{ IO.string8, "text" }
}

INCOMING[172] = {
	"onArizonaSetCurrentTask",
	{ IO.uint8,        "_unused" },
	{ IO.string8,      "text" },
	{ IO.stringUnread, "emoji" }
}

INCOMING[174] = {
	"onArizonaToggleDrawInterface",
	{ IO.bool8, "status" }
}

-- 180: uint16, bool8

INCOMING[183] = {
	"onArizonaSetVirtualWorld",
	{ IO.uint32, "world" }
}

INCOMING[187] = {
	"onArizonaSetVehicleDriftMode",
	{ IO.uint16, "vehicle_id" },
	{ IO.bool8, "state" }
}

INCOMING[193] = {
	"onArizonaSetVehicleLights",
	{ IO.uint16, "vehicle_id" },
	{ IO.string8, "light_name" }
}

INCOMING[209] = {
	"onArizonaSetVehicleStrobeligths",
	{ IO.uint16,       "vehicle_id" },
	{ IO.byteArray[6], "_unknown1" }
}

OUTGOING[0] = {
	"onArizonaSendKey",
	{ IO.uint8, "key" },
	{ IO.uint8, "_unknown" }
}

OUTGOING[1] = {
	"onArizonaSendSwitchChatState",
	{ IO.bool, "is_open" }
}

OUTGOING[17] = {
	"onArizonaSendOpenInterface",
	{ IO.uint32, "server_id" },
	{ IO.uint32, "menu_id" }
}

OUTGOING[18] = {
	"onArizonaSend",
	{ IO.string16, "text" },
	{ IO.uint32,   "server_id" }
}

OUTGOING[24] = {
	"onArizonaSendToggleDrawInterface",
	{ IO.uint32, "server_id" },
	{ IO.bool,   "status" }
}

OUTGOING[38] = {
	"onArizonaSendHash",
	{ IO.string[64], "hash" }
}

OUTGOING[140] = {
	"onArizonaSendClientJoin",
	{ IO.string16, "text" }
}

INCOMING_EX[50] = {
	"onArizonaBotStreamIn",
	{ IO.uint16,       "bot_id" },
	{ IO.int16,        "model_id" },
	{ IO.vector3d,     "position" },
	{ IO.float,        "rotation" },
	{ IO.bool,         "_padding" },
	{ IO.float,        "health" },
	{ IO.float,        "armour" },
	{ IO.byteArray[3], "_unknown1" },
	{
		{
			{ IO.int32, "color" },
			{ IO.string32, "text" }
		},
		"nametag_1"
	},
	{ IO.byteArray[1],  "_unknown2" },
	{
		{
			{ IO.int32, "color" },
			{ IO.string32, "text" }
		},
		"nametag_2"
	},
	{ IO.byteArray[7],  "_unknown3" }
}

INCOMING_EX[51] = {
	"onArizonaBotStreamOut",
	{ IO.uint16, "bot_id" }
}

INCOMING_EX[52] = {
	"onArizonaBotHealthSync",
	{ IO.uint16,       "bot_id" },
	{ IO.byteArray[4], "_unknown1" },
	{ IO.bool,         "_padding" },
	{ IO.float,        "health" },
	{ IO.float,        "max_health" },
	{ IO.float,        "armour" },
	{ IO.float,        "max_armour" },
	{ IO.byteArray[1], "_unknown2" }
}

INCOMING_EX[65] = {
	"onArizonaSetBotWeapon",
	{ IO.uint16, "bot_id" },
	{ IO.uint16, "weapon_id" },
	{ IO.uint8,  "_unknown1" }
}

INCOMING_EX[66] = {
	"onArizonaSetBotPos",
	{ IO.uint16, "bot_id" },
	{ IO.vector3d, "position" }
}

INCOMING_EX[67] = {
	"onArizonaSetBotTargetPos",
	{ IO.uint16,       "bot_id" },
	{ IO.vector3d,     "position" },
	{ IO.uint16,       "_unknown1" },
	{ IO.uint32,       "_unknown2" }
}

INCOMING_EX[69] = {
	"onArizonaApplyBotAnimation",
	{ IO.uint16,       "bot_id" },
	{ IO.string32,     "anim_lib" },
	{ IO.string32,     "anim_name" },
	{ IO.byteArray[9], "_unknown" }
}

INCOMING_EX[81] = {
	"onArizonaBotEnterVehicle",
	{ IO.uint16, "bot_id" },
	{ IO.uint16, "vehicle_id" },
	{ IO.int16,  "_unknown1" },
	{ IO.uint32, "_unknown2" },
}

INCOMING_EX[82] = {
	"onArizonaBotPassengerSync",
	{ IO.uint16, "bot_id" },
	{ IO.uint16, "vehicle_id" },
	{ IO.int16,  "seat_id" },
	{ IO.float,  "health" },
	{ IO.float,  "armour" }
}

INCOMING_EX[84] = {
	"onArizonaBotExitVehicle",
	{ IO.uint16, "bot_id" }
}

INCOMING_EX[85] = {
	"onArizonaBotChatBubble",
	{ IO.uint16,   "bot_id" },
	{ IO.string32, "text" },
	{ IO.int32,    "color" },
	{ IO.float,    "distance" },
	{ IO.int32,    "duration" }
}

INCOMING_EX[86] = {
	"onArizonaSetBotAttachedObject",
	{ IO.uint16,   "bot_id" },
	{ IO.uint16,   "slot" },
	{ IO.int32,    "model_id" },
	{ IO.int16,    "bone_id" },
	{ IO.vector3d, "offset" },
	{ IO.vector3d, "rotation" },
	{ IO.vector3d, "scale" },
	{ IO.int32,    "color1" },
	{ IO.int32,    "color2" }
}

INCOMING_EX[87] = {
	"onArizonaRemoveAttachedObjectFromBot",
	{ IO.uint16, "bot_id" },
	{ IO.uint16, "slot" }
}

INCOMING_EX[102] = {
	"onArizonaDestroyBot",
	{ IO.uint16, "bot_id" },
	{ IO.bool8,  "_unknown1" }
}

INCOMING_EX[103] = {
	"onArizonaSetBotAttachedSimpleObject",
	{ IO.uint16,   "bot_id" },
	{ IO.uint16,   "slot" },
	{ IO.int32,    "model_id" },
	{ IO.int16,    "bone_id" },
	{ IO.vector3d, "offset" },
	{ IO.vector3d, "rotation" },
	{ IO.vector3d, "scale" },
	{ IO.int32,    "color1" },
	{ IO.int32,    "color2" }
}

OUTGOING_EX[53] = {
	"onArizonaSendBotOnfootSync",
	{ IO.uint16,       "bot_id" },
	{ IO.vector3d,     "position" },
	{ IO.byteArray[4], "_unknown1" },
	{ IO.bool,         "_padding" },
	{ IO.float,        "heading" }, -- radian [-math.pi; math.pi]
	{ IO.byteArray[3], "_unknown2" }
}

OUTGOING_EX[73] = {
	"onArizonaSendBotDamage",
	{ IO.bool,   "give_or_take" },
	{ IO.uint16, "bot_id" },
	{ IO.float,  "damage" },
	{ IO.int32,  "weapon" },
	{ IO.int32,  "bodypart" },
	{ IO.uint16, "_unknown" },
	{ IO.uint16, "player_id" }
}

return module